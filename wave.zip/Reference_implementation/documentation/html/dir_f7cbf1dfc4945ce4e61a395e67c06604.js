var dir_f7cbf1dfc4945ce4e61a395e67c06604 =
[
    [ "bitstream.c", "bitstream_8c.html", "bitstream_8c" ],
    [ "bitstream.h", "bitstream_8h.html", "bitstream_8h" ],
    [ "compress.h", "compress_8h.html", "compress_8h" ],
    [ "compress_comb.c", "compress__comb_8c.html", "compress__comb_8c" ],
    [ "djbsort.h", "djbsort_8h.html", "djbsort_8h" ],
    [ "djbsort_portable.c", "djbsort__portable_8c.html", "djbsort__portable_8c" ],
    [ "gauss.c", "gauss_8c.html", "gauss_8c" ],
    [ "gauss.h", "gauss_8h.html", "gauss_8h" ],
    [ "hash.c", "hash_8c.html", "hash_8c" ],
    [ "hash.h", "hash_8h.html", "hash_8h" ],
    [ "mf3permut.c", "mf3permut_8c.html", "mf3permut_8c" ],
    [ "mf3permut.h", "mf3permut_8h.html", "mf3permut_8h" ],
    [ "popcount.h", "popcount_8h.html", "popcount_8h" ],
    [ "test_gauss.c", "test__gauss_8c.html", "test__gauss_8c" ],
    [ "tritstream.c", "tritstream_8c.html", "tritstream_8c" ],
    [ "tritstream.h", "tritstream_8h.html", "tritstream_8h" ]
];