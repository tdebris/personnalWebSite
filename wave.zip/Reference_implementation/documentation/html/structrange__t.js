var structrange__t =
[
    [ "max", "structrange__t.html#ae1e1dde676c120fa6d10f3bb2c14059e", null ],
    [ "min", "structrange__t.html#a3e202b201e6255d975cd6d3aff1f5a4d", null ]
];