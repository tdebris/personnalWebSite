var structwave__sk__t =
[
    [ "b", "structwave__sk__t.html#a5d06485b655e02c69420c55cf6ae1693", null ],
    [ "c", "structwave__sk__t.html#a9304c2b781aedf470d2322cc61792ef0", null ],
    [ "mk", "structwave__sk__t.html#a3e603d76898e5ff044dca32628a8acdb", null ],
    [ "perm", "structwave__sk__t.html#a4ff9e14224bb999c871c5b3f0217fcab", null ]
];