var structmf3__e =
[
    [ "n_col", "structmf3__e.html#ad9fdebd4b3aec2bfc3b526ce4f9da2d7", null ],
    [ "n_row", "structmf3__e.html#aa9f8b5204d49de7574e15d55d4a37cb9", null ],
    [ "rows", "structmf3__e.html#abdeb119354ba2e075d0d5384dfde453d", null ]
];