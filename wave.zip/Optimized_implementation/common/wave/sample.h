
#ifndef WAVE_SAMPLE_H
#define WAVE_SAMPLE_H

int sampleU(int t);
int sampleV();

#endif //WAVE_SAMPLE_H
