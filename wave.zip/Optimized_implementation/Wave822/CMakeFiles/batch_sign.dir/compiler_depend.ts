# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for batch_sign.
